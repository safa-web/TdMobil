package com.ramla.tdex2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import android.widget.Toast;

import static com.ramla.tdex2.R.id.action_context_bar;
import static com.ramla.tdex2.R.id.text1;
import static com.ramla.tdex2.R.id.text2;

public class MainActivity extends AppCompatActivity {

    private EditText mot1;
    private EditText mot2;
    private CheckBox c;
    private Button concate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.mot1=(EditText)findViewById(R.id.text1);
        this.mot2=(EditText)findViewById(R.id.text2);
        this.c=(CheckBox)findViewById(R.id.checkBox);

        this.concate=(Button)findViewById(R.id.btn);


    }
    public void Concat(View view) {
        String m1=mot1.getText().toString();
        String m2 = mot2.getText().toString();

        if (m1.isEmpty() || m2.isEmpty())
            Toast.makeText(this, "isEmpty!", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(this,m1.concat(m2), Toast.LENGTH_SHORT).show();

    }

    public void espace(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        String e=mot1.getText()+" ";
        if(checked)
            mot1.setText( e );


    }

}