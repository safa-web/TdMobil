package com.ramla.tdex3;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
public class MainActivity extends AppCompatActivity {
    private int e2;
    private EditText s1;
    private EditText s2;
    private EditText res;
    private RadioButton radio;
    private Button egal;
    private RadioButton br1;
    private RadioButton br2;
    private RadioButton br3;
    private RadioButton br4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        s2 = (EditText) findViewById(R.id.entier2);
        s1 = (EditText) findViewById(R.id.entier1);
        res = (EditText) findViewById(R.id.resultat);
        br1=(RadioButton)findViewById(R.id.r1);
        br2=(RadioButton)findViewById(R.id.r2);
        br3=(RadioButton)findViewById(R.id.r3);
        br4=(RadioButton)findViewById(R.id.r4);

    }
    public void add(View v )
    {
        int c=  Integer.parseInt(s2.getText().toString());
        int c1=  Integer.parseInt(s1.getText().toString());
        int somme=c+c1;
        res.setText(String.valueOf(somme));
    }
    public void neg(View v )
    {
        int c=  Integer.parseInt(s2.getText().toString());
        int c1=  Integer.parseInt(s1.getText().toString());
        int somme=c-c1;
        res.setText(String.valueOf(somme));
    }
    public void mul(View v )
    {
        int c=  Integer.parseInt(s2.getText().toString());
        int c1=  Integer.parseInt(s1.getText().toString());
        int somme=c*c1;
        res.setText(String.valueOf(somme));
    }
    public void devi(View v )
    {
        int c=  Integer.parseInt(s2.getText().toString());
        int c1=  Integer.parseInt(s1.getText().toString());
        int somme=c/c1;
        res.setText(String.valueOf(somme));
    }
    public void calculeresultat(View v )
    {
        int c=  Integer.parseInt(s2.getText().toString());
        int c1=  Integer.parseInt(s1.getText().toString());
        if(br1.isChecked())
        {
            int somme=c+c1;
            res.setText(String.valueOf(somme));

        }
        if(br2.isChecked())
        {
            int somme=c-c1;
            res.setText(String.valueOf(somme));

        }
        if(br3.isChecked())
        {
            int somme=c*c1;
            res.setText(String.valueOf(somme));

        }
        if(br4.isChecked())
        {
            int somme=c/c1;
            res.setText(String.valueOf(somme));

        }
    }
    public boolean isEmpty(CharSequence str) {
        if (str == null || str.length() == 0)
            return true;
        else
            return false;
    }
    private void entier1_isEmpty () {
        String textMot1 = s1.getText().toString().trim();
        if (textMot1.isEmpty()) {
            s1.setError("Remplir votre champ");
        } else {
            s1.setError(null);
        }
    }
    private void entier2_isEmpty () {
        String textMot1 = s2.getText().toString().trim();
        if (textMot1.isEmpty()) {
            s1.setError("Remplir votre chapms");
        } else {
            s1.setError(null);
        }
    }
}